﻿ <?php
  
    $servername = "localhost";
    $username = "root";
    $password = "raspberry";
    $dbname = "lora_data";

	// Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);
    // Check connection
    if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
    }
	 $sql = "SELECT DeviceID,Timestamp,EU,VI,sw,temp,hum FROM test";
                $result = $conn->query($sql);
   if ($result->num_rows > 0) {
     while($row = $result->fetch_assoc()) {
        echo "id: " . $row["DeviceID"]. " - Name: " . $row["Timestamp"]. " " . $row["EU"]. "<br>";
    }
} else {
    echo "0 results";
}
$conn->close();
?>
                          